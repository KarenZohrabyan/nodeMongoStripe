const passport = require('passport');
const VKontakteStrategy = require('passport-vkontakte').Strategy;
const User = require('./models/user');

passport.serializeUser((user, done) => {
  console.log(user.id.toString());
  done(null, user.id.toString());
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id); 
    console.log(user);
    if (!user) {
      return done({ error: "Could not find user" }, false);
    };
    done(null, user);
  } catch (e) {
    done({ error: e.message }, false);
  }
});

passport.use(new VKontakteStrategy(
  {
    clientID: '7771460', // VK.com docs call it 'API ID', 'app_id', 'api_id', 'client_id' or 'apiId'
    clientSecret: 'Dr9YMU3ODCTn9UfnOhne',
    callbackURL: "http://localhost:3000/vkontakte/callback"
  },
  async function myVerifyCallbackFn(accessToken, refreshToken, params, profile, done) {

    const findU = await User.findOne({ userId: params.user_id });

    if (!findU) {
      const user = new User({
        accessToken: accessToken,
        expires_in: params.expires_in,
        userId: params.user_id,
        email: params.email,
        userName: profile.username,
        displayName: profile.displayName
      })
      await user.save()
    } else {
      findU.accessToken = accessToken
      await findU.save()

    }

    return done(null, profile);
  }
));

