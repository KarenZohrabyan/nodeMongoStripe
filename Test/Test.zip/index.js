const express = require('express');
const auth = require('./src/auth');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const expressSession = require('express-session');
const passport = require('passport');
const cookieSession = require('cookie-session');
require('./src/auth');
require('./src/db/mongoose');
const User = require('./src/models/user');

const app = express();
const port = 3000;


// app.use(cookieParser());
app.use(cookieSession({
  maxAge: 48 * 60 * 60 * 1000,
  keys: ['test']
}));

//Routes
// app.use(express.static('views'))
// app.use(bodyParser.urlencoded({extended: true}));
// app.use(expressSession({secret: 'keyboard cat', resave: true, saveUninitialized: true}));

// app.use(bodyParser.json());
app.use(passport.initialize());
app.use(passport.session());
app.set('view engine', 'ejs');

// app.use(passport.authenticate('session'))



//For User
app.post('/user', async (req, res) => {
  const user = new User(req.body)

  await user.save()
  // user.save().then(() => {
  //   res.send(user);
  // }).catch((error) => {
  //   res.send(error);
  // })
})


app.get('/', (req, res) => {
    res.render('success.ejs')
})

app.get('/signup', (req, res) => {
    res.render('index.ejs');
})

app.get('/login', (req, res) => {
    res.send('Failed!');
})

// const check = async (req, res, next) => {
//   res.cookie('cookieName', 'cookieValue'),
//   next();
// }

app.get('/auth/vkontakte', passport.authenticate('vkontakte', 
{ 
    scope: ['status', 'email', 'friends', 'notify', 'offline'],
}),
  function(req,res){
    // console.log(res);
  }
);

app.get('/vkontakte/callback',
  passport.authenticate('vkontakte', {
    successRedirect: '/',
    failureRedirect: '/login',
  }), (req,res) => {
    res.send('test')
  }
);

app.get("/", function (req, res) {
  //Here you have an access to req.user
  res.render(req.user);
});


app.listen(port);